#include<stdio.h>
#include<stdlib.h>

main()
{
	system("arecord just.wav");
	
	getchar();getchar();
}
